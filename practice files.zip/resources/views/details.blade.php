@extends('layouts.layout')
@section('content')
<div class="albums-header">
    <h1 style="text-align: center;">Albums</h1>
</div>
<div style="width: 100%;">
    <h1 style="text-align: center;">Albums</h1>
    {{-- @for($i = 0; $i < count($pizzas); $i++)
        <p>{{$pizzas[$i]['type']}}</p>
    @endfor --}}
    <h1>ALmum id - {{$id}}</h1>
</div>
@endsection